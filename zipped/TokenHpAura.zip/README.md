# token-health-aura
Module that will place a small aura around tokens at varying thresholds of HP.

Systems: 5e


![Tokens Page](https://github.com/ieru00/fdr-token-hp-aura/blob/main/z_bs_imgs/Token_Page.png?raw=true)
![Roll All Page](https://github.com/ieru00/fdr-token-hp-aura/blob/main/z_bs_imgs/Roll_All_Page.png?raw=true)


